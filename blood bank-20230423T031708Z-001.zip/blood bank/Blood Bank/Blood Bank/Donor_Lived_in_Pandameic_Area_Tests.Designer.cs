﻿
namespace Blood_Bank
{
    partial class Donor_Lived_in_Pandameic_Area_Tests
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label25 = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.label24 = new System.Windows.Forms.Label();
            this.txtbloodunitid = new System.Windows.Forms.TextBox();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.lbchagas = new System.Windows.Forms.Label();
            this.cbTCZ = new System.Windows.Forms.ComboBox();
            this.btnchagaselibility = new System.Windows.Forms.Button();
            this.cbMNC = new System.Windows.Forms.ComboBox();
            this.btnchagasupdate = new System.Windows.Forms.Button();
            this.label20 = new System.Windows.Forms.Label();
            this.btnchagasinsert = new System.Windows.Forms.Button();
            this.btnchagasconfirm = new System.Windows.Forms.Button();
            this.label21 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.lbwest = new System.Windows.Forms.Label();
            this.btnwesteligibility = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.txtspeIgMCSF = new System.Windows.Forms.TextBox();
            this.btnwestconfirm = new System.Windows.Forms.Button();
            this.btnwestupdate = new System.Windows.Forms.Button();
            this.txtspIgMSerum = new System.Windows.Forms.TextBox();
            this.txtPCRCSF = new System.Windows.Forms.TextBox();
            this.btnwestinsert = new System.Windows.Forms.Button();
            this.txtPCRSerum = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.lbcyto = new System.Windows.Forms.Label();
            this.btncytomegaloeligibility = new System.Windows.Forms.Button();
            this.comboBox3 = new System.Windows.Forms.ComboBox();
            this.cbCMVIgGAvidity = new System.Windows.Forms.ComboBox();
            this.cbCMVIgM = new System.Windows.Forms.ComboBox();
            this.cbCMVIgG = new System.Windows.Forms.ComboBox();
            this.label12 = new System.Windows.Forms.Label();
            this.btncytomegaloupdate = new System.Windows.Forms.Button();
            this.btncytomegaloconfirm = new System.Windows.Forms.Button();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.btncytomegaloinsert = new System.Windows.Forms.Button();
            this.groupBox2.SuspendLayout();
            this.groupBox5.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.SuspendLayout();
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label25.Location = new System.Drawing.Point(408, 366);
            this.label25.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(79, 18);
            this.label25.TabIndex = 19;
            this.label25.Text = " Eligibility";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.label24);
            this.groupBox2.Controls.Add(this.txtbloodunitid);
            this.groupBox2.Location = new System.Drawing.Point(56, 40);
            this.groupBox2.Margin = new System.Windows.Forms.Padding(2);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Padding = new System.Windows.Forms.Padding(2);
            this.groupBox2.Size = new System.Drawing.Size(334, 50);
            this.groupBox2.TabIndex = 18;
            this.groupBox2.TabStop = false;
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label24.Location = new System.Drawing.Point(14, 21);
            this.label24.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(83, 13);
            this.label24.TabIndex = 11;
            this.label24.Text = "Blood Unit ID";
            // 
            // txtbloodunitid
            // 
            this.txtbloodunitid.Location = new System.Drawing.Point(135, 17);
            this.txtbloodunitid.Margin = new System.Windows.Forms.Padding(2);
            this.txtbloodunitid.Name = "txtbloodunitid";
            this.txtbloodunitid.Size = new System.Drawing.Size(136, 20);
            this.txtbloodunitid.TabIndex = 12;
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.lbchagas);
            this.groupBox5.Controls.Add(this.cbTCZ);
            this.groupBox5.Controls.Add(this.btnchagaselibility);
            this.groupBox5.Controls.Add(this.cbMNC);
            this.groupBox5.Controls.Add(this.btnchagasupdate);
            this.groupBox5.Controls.Add(this.label20);
            this.groupBox5.Controls.Add(this.btnchagasinsert);
            this.groupBox5.Controls.Add(this.btnchagasconfirm);
            this.groupBox5.Controls.Add(this.label21);
            this.groupBox5.Location = new System.Drawing.Point(397, 191);
            this.groupBox5.Margin = new System.Windows.Forms.Padding(2);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Padding = new System.Windows.Forms.Padding(2);
            this.groupBox5.Size = new System.Drawing.Size(476, 157);
            this.groupBox5.TabIndex = 17;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "CHAGAS";
            // 
            // lbchagas
            // 
            this.lbchagas.AutoSize = true;
            this.lbchagas.Location = new System.Drawing.Point(378, 100);
            this.lbchagas.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lbchagas.Name = "lbchagas";
            this.lbchagas.Size = new System.Drawing.Size(46, 13);
            this.lbchagas.TabIndex = 48;
            this.lbchagas.Text = "Eligibility";
            // 
            // cbTCZ
            // 
            this.cbTCZ.FormattingEnabled = true;
            this.cbTCZ.Items.AddRange(new object[] {
            "POSITIVE(17)",
            "Negative"});
            this.cbTCZ.Location = new System.Drawing.Point(156, 54);
            this.cbTCZ.Name = "cbTCZ";
            this.cbTCZ.Size = new System.Drawing.Size(121, 21);
            this.cbTCZ.TabIndex = 9;
            // 
            // btnchagaselibility
            // 
            this.btnchagaselibility.Location = new System.Drawing.Point(267, 96);
            this.btnchagaselibility.Margin = new System.Windows.Forms.Padding(2);
            this.btnchagaselibility.Name = "btnchagaselibility";
            this.btnchagaselibility.Size = new System.Drawing.Size(97, 21);
            this.btnchagaselibility.TabIndex = 47;
            this.btnchagaselibility.Text = "Check Eligibility";
            this.btnchagaselibility.UseVisualStyleBackColor = true;
            this.btnchagaselibility.Click += new System.EventHandler(this.btnchagaselibility_Click_1);
            // 
            // cbMNC
            // 
            this.cbMNC.FormattingEnabled = true;
            this.cbMNC.Items.AddRange(new object[] {
            "POSITIVE(22)",
            "POSITIVE(21)",
            "Negative"});
            this.cbMNC.Location = new System.Drawing.Point(14, 54);
            this.cbMNC.Name = "cbMNC";
            this.cbMNC.Size = new System.Drawing.Size(121, 21);
            this.cbMNC.TabIndex = 8;
            // 
            // btnchagasupdate
            // 
            this.btnchagasupdate.Location = new System.Drawing.Point(289, 53);
            this.btnchagasupdate.Margin = new System.Windows.Forms.Padding(2);
            this.btnchagasupdate.Name = "btnchagasupdate";
            this.btnchagasupdate.Size = new System.Drawing.Size(56, 21);
            this.btnchagasupdate.TabIndex = 43;
            this.btnchagasupdate.Text = "Update";
            this.btnchagasupdate.UseVisualStyleBackColor = true;
            this.btnchagasupdate.Click += new System.EventHandler(this.btnchagasupdate_Click_1);
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(188, 32);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(71, 13);
            this.label20.TabIndex = 7;
            this.label20.Text = "TCZ TaqMan";
            // 
            // btnchagasinsert
            // 
            this.btnchagasinsert.Location = new System.Drawing.Point(410, 53);
            this.btnchagasinsert.Margin = new System.Windows.Forms.Padding(2);
            this.btnchagasinsert.Name = "btnchagasinsert";
            this.btnchagasinsert.Size = new System.Drawing.Size(56, 21);
            this.btnchagasinsert.TabIndex = 41;
            this.btnchagasinsert.Text = "Insert";
            this.btnchagasinsert.UseVisualStyleBackColor = true;
            this.btnchagasinsert.Click += new System.EventHandler(this.btnchagasinsert_Click_1);
            // 
            // btnchagasconfirm
            // 
            this.btnchagasconfirm.Location = new System.Drawing.Point(349, 53);
            this.btnchagasconfirm.Margin = new System.Windows.Forms.Padding(2);
            this.btnchagasconfirm.Name = "btnchagasconfirm";
            this.btnchagasconfirm.Size = new System.Drawing.Size(56, 21);
            this.btnchagasconfirm.TabIndex = 42;
            this.btnchagasconfirm.Text = "Confirm";
            this.btnchagasconfirm.UseVisualStyleBackColor = true;
            this.btnchagasconfirm.Click += new System.EventHandler(this.btnchagasconfirm_Click_1);
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(35, 32);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(74, 13);
            this.label21.TabIndex = 6;
            this.label21.Text = "MNC TaqMan";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.lbwest);
            this.groupBox1.Controls.Add(this.btnwesteligibility);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.txtspeIgMCSF);
            this.groupBox1.Controls.Add(this.btnwestconfirm);
            this.groupBox1.Controls.Add(this.btnwestupdate);
            this.groupBox1.Controls.Add(this.txtspIgMSerum);
            this.groupBox1.Controls.Add(this.txtPCRCSF);
            this.groupBox1.Controls.Add(this.btnwestinsert);
            this.groupBox1.Controls.Add(this.txtPCRSerum);
            this.groupBox1.Controls.Add(this.label8);
            this.groupBox1.Controls.Add(this.label7);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Location = new System.Drawing.Point(56, 94);
            this.groupBox1.Margin = new System.Windows.Forms.Padding(2);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(2);
            this.groupBox1.Size = new System.Drawing.Size(334, 254);
            this.groupBox1.TabIndex = 16;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = " WEST NILE VIRUS";
            // 
            // lbwest
            // 
            this.lbwest.AutoSize = true;
            this.lbwest.Location = new System.Drawing.Point(248, 224);
            this.lbwest.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lbwest.Name = "lbwest";
            this.lbwest.Size = new System.Drawing.Size(46, 13);
            this.lbwest.TabIndex = 43;
            this.lbwest.Text = "Eligibility";
            // 
            // btnwesteligibility
            // 
            this.btnwesteligibility.Location = new System.Drawing.Point(147, 220);
            this.btnwesteligibility.Margin = new System.Windows.Forms.Padding(2);
            this.btnwesteligibility.Name = "btnwesteligibility";
            this.btnwesteligibility.Size = new System.Drawing.Size(97, 21);
            this.btnwesteligibility.TabIndex = 42;
            this.btnwesteligibility.Text = "Check Eligibility";
            this.btnwesteligibility.UseVisualStyleBackColor = true;
            this.btnwesteligibility.Click += new System.EventHandler(this.btnwesteligibility_Click_1);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(211, 15);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(90, 13);
            this.label3.TabIndex = 29;
            this.label3.Text = "SENSITIVITY (%)";
            // 
            // txtspeIgMCSF
            // 
            this.txtspeIgMCSF.Location = new System.Drawing.Point(200, 142);
            this.txtspeIgMCSF.Name = "txtspeIgMCSF";
            this.txtspeIgMCSF.Size = new System.Drawing.Size(100, 20);
            this.txtspeIgMCSF.TabIndex = 28;
            // 
            // btnwestconfirm
            // 
            this.btnwestconfirm.Location = new System.Drawing.Point(99, 185);
            this.btnwestconfirm.Margin = new System.Windows.Forms.Padding(2);
            this.btnwestconfirm.Name = "btnwestconfirm";
            this.btnwestconfirm.Size = new System.Drawing.Size(56, 21);
            this.btnwestconfirm.TabIndex = 37;
            this.btnwestconfirm.Text = "Confirm";
            this.btnwestconfirm.UseVisualStyleBackColor = true;
            this.btnwestconfirm.Click += new System.EventHandler(this.btnwestconfirm_Click);
            // 
            // btnwestupdate
            // 
            this.btnwestupdate.Location = new System.Drawing.Point(171, 185);
            this.btnwestupdate.Margin = new System.Windows.Forms.Padding(2);
            this.btnwestupdate.Name = "btnwestupdate";
            this.btnwestupdate.Size = new System.Drawing.Size(56, 21);
            this.btnwestupdate.TabIndex = 38;
            this.btnwestupdate.Text = "Update";
            this.btnwestupdate.UseVisualStyleBackColor = true;
            this.btnwestupdate.Click += new System.EventHandler(this.btnwestupdate_Click);
            // 
            // txtspIgMSerum
            // 
            this.txtspIgMSerum.Location = new System.Drawing.Point(200, 106);
            this.txtspIgMSerum.Name = "txtspIgMSerum";
            this.txtspIgMSerum.Size = new System.Drawing.Size(100, 20);
            this.txtspIgMSerum.TabIndex = 27;
            // 
            // txtPCRCSF
            // 
            this.txtPCRCSF.Location = new System.Drawing.Point(200, 67);
            this.txtPCRCSF.Name = "txtPCRCSF";
            this.txtPCRCSF.Size = new System.Drawing.Size(100, 20);
            this.txtPCRCSF.TabIndex = 26;
            // 
            // btnwestinsert
            // 
            this.btnwestinsert.Location = new System.Drawing.Point(242, 185);
            this.btnwestinsert.Margin = new System.Windows.Forms.Padding(2);
            this.btnwestinsert.Name = "btnwestinsert";
            this.btnwestinsert.Size = new System.Drawing.Size(56, 21);
            this.btnwestinsert.TabIndex = 36;
            this.btnwestinsert.Text = "Insert";
            this.btnwestinsert.UseVisualStyleBackColor = true;
            this.btnwestinsert.Click += new System.EventHandler(this.btnwestinsert_Click);
            // 
            // txtPCRSerum
            // 
            this.txtPCRSerum.Location = new System.Drawing.Point(200, 36);
            this.txtPCRSerum.Name = "txtPCRSerum";
            this.txtPCRSerum.Size = new System.Drawing.Size(100, 20);
            this.txtPCRSerum.TabIndex = 25;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(34, 146);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(127, 13);
            this.label8.TabIndex = 20;
            this.label8.Text = "WNV_Specific_IgM_CSF";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(34, 109);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(137, 13);
            this.label7.TabIndex = 19;
            this.label7.Text = "WNV_Specific_IgM_Serum";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(34, 75);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(55, 13);
            this.label6.TabIndex = 18;
            this.label6.Text = "PCR_CSF";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(34, 38);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(65, 13);
            this.label5.TabIndex = 17;
            this.label5.Text = "PCR_Serum";
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.lbcyto);
            this.groupBox4.Controls.Add(this.btncytomegaloeligibility);
            this.groupBox4.Controls.Add(this.comboBox3);
            this.groupBox4.Controls.Add(this.cbCMVIgGAvidity);
            this.groupBox4.Controls.Add(this.cbCMVIgM);
            this.groupBox4.Controls.Add(this.cbCMVIgG);
            this.groupBox4.Controls.Add(this.label12);
            this.groupBox4.Controls.Add(this.btncytomegaloupdate);
            this.groupBox4.Controls.Add(this.btncytomegaloconfirm);
            this.groupBox4.Controls.Add(this.label13);
            this.groupBox4.Controls.Add(this.label14);
            this.groupBox4.Controls.Add(this.btncytomegaloinsert);
            this.groupBox4.Location = new System.Drawing.Point(395, 40);
            this.groupBox4.Margin = new System.Windows.Forms.Padding(2);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Padding = new System.Windows.Forms.Padding(2);
            this.groupBox4.Size = new System.Drawing.Size(478, 146);
            this.groupBox4.TabIndex = 15;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "CYTOMEGALOVIRUS";
            // 
            // lbcyto
            // 
            this.lbcyto.AutoSize = true;
            this.lbcyto.Location = new System.Drawing.Point(380, 124);
            this.lbcyto.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lbcyto.Name = "lbcyto";
            this.lbcyto.Size = new System.Drawing.Size(46, 13);
            this.lbcyto.TabIndex = 46;
            this.lbcyto.Text = "Eligibility";
            // 
            // btncytomegaloeligibility
            // 
            this.btncytomegaloeligibility.Location = new System.Drawing.Point(268, 118);
            this.btncytomegaloeligibility.Margin = new System.Windows.Forms.Padding(2);
            this.btncytomegaloeligibility.Name = "btncytomegaloeligibility";
            this.btncytomegaloeligibility.Size = new System.Drawing.Size(97, 21);
            this.btncytomegaloeligibility.TabIndex = 45;
            this.btncytomegaloeligibility.Text = "Check Eligibility";
            this.btncytomegaloeligibility.UseVisualStyleBackColor = true;
            this.btncytomegaloeligibility.Click += new System.EventHandler(this.btncytomegaloeligibility_Click_1);
            // 
            // comboBox3
            // 
            this.comboBox3.FormattingEnabled = true;
            this.comboBox3.Items.AddRange(new object[] {
            "N/A",
            "High Avidity",
            "Low Avidity",
            "High Avidity"});
            this.comboBox3.Location = new System.Drawing.Point(502, -48);
            this.comboBox3.Name = "comboBox3";
            this.comboBox3.Size = new System.Drawing.Size(121, 21);
            this.comboBox3.TabIndex = 44;
            // 
            // cbCMVIgGAvidity
            // 
            this.cbCMVIgGAvidity.FormattingEnabled = true;
            this.cbCMVIgGAvidity.Items.AddRange(new object[] {
            "N/A",
            "High Avidity",
            "Low Avidity"});
            this.cbCMVIgGAvidity.Location = new System.Drawing.Point(340, 54);
            this.cbCMVIgGAvidity.Name = "cbCMVIgGAvidity";
            this.cbCMVIgGAvidity.Size = new System.Drawing.Size(121, 21);
            this.cbCMVIgGAvidity.TabIndex = 13;
            // 
            // cbCMVIgM
            // 
            this.cbCMVIgM.FormattingEnabled = true;
            this.cbCMVIgM.Items.AddRange(new object[] {
            "Non - Reactive",
            "Reactive",
            ""});
            this.cbCMVIgM.Location = new System.Drawing.Point(178, 54);
            this.cbCMVIgM.Name = "cbCMVIgM";
            this.cbCMVIgM.Size = new System.Drawing.Size(121, 21);
            this.cbCMVIgM.TabIndex = 12;
            // 
            // cbCMVIgG
            // 
            this.cbCMVIgG.FormattingEnabled = true;
            this.cbCMVIgG.Items.AddRange(new object[] {
            "NonReactive",
            "Reactive"});
            this.cbCMVIgG.Location = new System.Drawing.Point(24, 54);
            this.cbCMVIgG.Name = "cbCMVIgG";
            this.cbCMVIgG.Size = new System.Drawing.Size(121, 21);
            this.cbCMVIgG.TabIndex = 11;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(356, 29);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(84, 13);
            this.label12.TabIndex = 10;
            this.label12.Text = "CMV IgG Avidity";
            // 
            // btncytomegaloupdate
            // 
            this.btncytomegaloupdate.Location = new System.Drawing.Point(242, 89);
            this.btncytomegaloupdate.Margin = new System.Windows.Forms.Padding(2);
            this.btncytomegaloupdate.Name = "btncytomegaloupdate";
            this.btncytomegaloupdate.Size = new System.Drawing.Size(56, 21);
            this.btncytomegaloupdate.TabIndex = 33;
            this.btncytomegaloupdate.Text = "Update";
            this.btncytomegaloupdate.UseVisualStyleBackColor = true;
            this.btncytomegaloupdate.Click += new System.EventHandler(this.btncytomegaloupdate_Click_1);
            // 
            // btncytomegaloconfirm
            // 
            this.btncytomegaloconfirm.Location = new System.Drawing.Point(324, 89);
            this.btncytomegaloconfirm.Margin = new System.Windows.Forms.Padding(2);
            this.btncytomegaloconfirm.Name = "btncytomegaloconfirm";
            this.btncytomegaloconfirm.Size = new System.Drawing.Size(56, 21);
            this.btncytomegaloconfirm.TabIndex = 32;
            this.btncytomegaloconfirm.Text = "Confirm";
            this.btncytomegaloconfirm.UseVisualStyleBackColor = true;
            this.btncytomegaloconfirm.Click += new System.EventHandler(this.btncytomegaloconfirm_Click_1);
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(211, 29);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(51, 13);
            this.label13.TabIndex = 9;
            this.label13.Text = "CMV IgM";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(51, 29);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(50, 13);
            this.label14.TabIndex = 8;
            this.label14.Text = "CMV IgG";
            // 
            // btncytomegaloinsert
            // 
            this.btncytomegaloinsert.Location = new System.Drawing.Point(404, 88);
            this.btncytomegaloinsert.Margin = new System.Windows.Forms.Padding(2);
            this.btncytomegaloinsert.Name = "btncytomegaloinsert";
            this.btncytomegaloinsert.Size = new System.Drawing.Size(56, 21);
            this.btncytomegaloinsert.TabIndex = 31;
            this.btncytomegaloinsert.Text = "Insert";
            this.btncytomegaloinsert.UseVisualStyleBackColor = true;
            this.btncytomegaloinsert.Click += new System.EventHandler(this.btncytomegaloinsert_Click_1);
            // 
            // Donor_Lived_in_Pandameic_Area_Tests
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Window;
            this.ClientSize = new System.Drawing.Size(928, 403);
            this.Controls.Add(this.label25);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox5);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.groupBox4);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Name = "Donor_Lived_in_Pandameic_Area_Tests";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Donor_Lived_in_Pandameic_Area_Tests";
            this.Load += new System.EventHandler(this.Donor_Lived_in_Pandameic_Area_Tests_Load);
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox5.ResumeLayout(false);
            this.groupBox5.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.TextBox txtbloodunitid;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.Label lbchagas;
        private System.Windows.Forms.ComboBox cbTCZ;
        private System.Windows.Forms.Button btnchagaselibility;
        private System.Windows.Forms.ComboBox cbMNC;
        private System.Windows.Forms.Button btnchagasupdate;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Button btnchagasinsert;
        private System.Windows.Forms.Button btnchagasconfirm;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label lbwest;
        private System.Windows.Forms.Button btnwesteligibility;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtspeIgMCSF;
        private System.Windows.Forms.Button btnwestconfirm;
        private System.Windows.Forms.Button btnwestupdate;
        private System.Windows.Forms.TextBox txtspIgMSerum;
        private System.Windows.Forms.TextBox txtPCRCSF;
        private System.Windows.Forms.Button btnwestinsert;
        private System.Windows.Forms.TextBox txtPCRSerum;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.Label lbcyto;
        private System.Windows.Forms.Button btncytomegaloeligibility;
        private System.Windows.Forms.ComboBox comboBox3;
        private System.Windows.Forms.ComboBox cbCMVIgGAvidity;
        private System.Windows.Forms.ComboBox cbCMVIgM;
        private System.Windows.Forms.ComboBox cbCMVIgG;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Button btncytomegaloupdate;
        private System.Windows.Forms.Button btncytomegaloconfirm;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Button btncytomegaloinsert;
    }
}