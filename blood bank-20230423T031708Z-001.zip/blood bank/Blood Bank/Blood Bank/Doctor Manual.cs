﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Blood_Bank
{
    public partial class Doctor_Manual : Form
    {
        public Doctor_Manual()
        {
            InitializeComponent();
        }

        private void Doctor_Manual_Load(object sender, EventArgs e)
        {

        }
    }
}
