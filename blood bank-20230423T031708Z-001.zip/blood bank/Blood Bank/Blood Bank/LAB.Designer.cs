﻿
namespace Blood_Bank
{
    partial class LAB
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.viewAccountToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.viewAndEditAccountToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.backToTheMainMenuToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.aboutWhatToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.userManualToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.aboutSoftwareToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.groupBox8 = new System.Windows.Forms.GroupBox();
            this.btnbtconfirm = new System.Windows.Forms.Button();
            this.txtbtype = new System.Windows.Forms.TextBox();
            this.label31 = new System.Windows.Forms.Label();
            this.btnupdateBtype = new System.Windows.Forms.Button();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.button2 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.label30 = new System.Windows.Forms.Label();
            this.btncheck = new System.Windows.Forms.Button();
            this.label29 = new System.Windows.Forms.Label();
            this.txtDNIC = new System.Windows.Forms.TextBox();
            this.label24 = new System.Windows.Forms.Label();
            this.txtDDate = new System.Windows.Forms.TextBox();
            this.txtbloodunitid = new System.Windows.Forms.TextBox();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.button21 = new System.Windows.Forms.Button();
            this.finalEligibility = new System.Windows.Forms.Button();
            this.label23 = new System.Windows.Forms.Label();
            this.button20 = new System.Windows.Forms.Button();
            this.label25 = new System.Windows.Forms.Label();
            this.txtpan = new System.Windows.Forms.TextBox();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.label28 = new System.Windows.Forms.Label();
            this.label27 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.btnlipidupdate = new System.Windows.Forms.Button();
            this.btnlipidconfirm = new System.Windows.Forms.Button();
            this.btnlipidinsert = new System.Windows.Forms.Button();
            this.txtLDLHDL = new System.Windows.Forms.TextBox();
            this.txtCHOLHDL = new System.Windows.Forms.TextBox();
            this.txtCVLDL = new System.Windows.Forms.TextBox();
            this.txtCLDL = new System.Windows.Forms.TextBox();
            this.txtCNonHDL = new System.Windows.Forms.TextBox();
            this.txtCHDL = new System.Windows.Forms.TextBox();
            this.txtTriglycerides = new System.Windows.Forms.TextBox();
            this.txtcholesterol = new System.Windows.Forms.TextBox();
            this.label19 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.lbsyphilis = new System.Windows.Forms.Label();
            this.btnsyphilisisupdate = new System.Windows.Forms.Button();
            this.btnsyphiliseligibility = new System.Windows.Forms.Button();
            this.btnsyphilisinsert = new System.Windows.Forms.Button();
            this.btnsyphilisconfirm = new System.Windows.Forms.Button();
            this.cbsperdr = new System.Windows.Forms.ComboBox();
            this.cbnonsperdr = new System.Windows.Forms.ComboBox();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.lbhepatitis = new System.Windows.Forms.Label();
            this.cbHepatitis = new System.Windows.Forms.ComboBox();
            this.btnhepatitiseligibility = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.btnhepatitisupdate = new System.Windows.Forms.Button();
            this.btnhepatitisinsert = new System.Windows.Forms.Button();
            this.btnhepatitisconfirm = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.lbhiv = new System.Windows.Forms.Label();
            this.btnhiveligibility = new System.Windows.Forms.Button();
            this.btnhivupdate = new System.Windows.Forms.Button();
            this.btnhivconfirm = new System.Windows.Forms.Button();
            this.btnhivinsert = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.txthivrna = new System.Windows.Forms.TextBox();
            this.txthiv2 = new System.Windows.Forms.TextBox();
            this.txthiv1 = new System.Windows.Forms.TextBox();
            this.txtGRF = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.menuStrip1.SuspendLayout();
            this.groupBox8.SuspendLayout();
            this.groupBox5.SuspendLayout();
            this.groupBox6.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.viewAccountToolStripMenuItem,
            this.aboutWhatToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(958, 24);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // viewAccountToolStripMenuItem
            // 
            this.viewAccountToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.viewAndEditAccountToolStripMenuItem,
            this.backToTheMainMenuToolStripMenuItem});
            this.viewAccountToolStripMenuItem.Name = "viewAccountToolStripMenuItem";
            this.viewAccountToolStripMenuItem.Size = new System.Drawing.Size(92, 20);
            this.viewAccountToolStripMenuItem.Text = "View Account";
            this.viewAccountToolStripMenuItem.Click += new System.EventHandler(this.viewAccountToolStripMenuItem_Click);
            // 
            // viewAndEditAccountToolStripMenuItem
            // 
            this.viewAndEditAccountToolStripMenuItem.Name = "viewAndEditAccountToolStripMenuItem";
            this.viewAndEditAccountToolStripMenuItem.Size = new System.Drawing.Size(200, 22);
            this.viewAndEditAccountToolStripMenuItem.Text = "View And Edit Account";
            this.viewAndEditAccountToolStripMenuItem.Click += new System.EventHandler(this.viewAndEditAccountToolStripMenuItem_Click);
            // 
            // backToTheMainMenuToolStripMenuItem
            // 
            this.backToTheMainMenuToolStripMenuItem.Name = "backToTheMainMenuToolStripMenuItem";
            this.backToTheMainMenuToolStripMenuItem.Size = new System.Drawing.Size(200, 22);
            this.backToTheMainMenuToolStripMenuItem.Text = "Back To The Main Menu";
            this.backToTheMainMenuToolStripMenuItem.Click += new System.EventHandler(this.backToTheMainMenuToolStripMenuItem_Click);
            // 
            // aboutWhatToolStripMenuItem
            // 
            this.aboutWhatToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.userManualToolStripMenuItem,
            this.aboutSoftwareToolStripMenuItem});
            this.aboutWhatToolStripMenuItem.Name = "aboutWhatToolStripMenuItem";
            this.aboutWhatToolStripMenuItem.Size = new System.Drawing.Size(83, 20);
            this.aboutWhatToolStripMenuItem.Text = "About What";
            // 
            // userManualToolStripMenuItem
            // 
            this.userManualToolStripMenuItem.Name = "userManualToolStripMenuItem";
            this.userManualToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.userManualToolStripMenuItem.Text = "User Manual";
            this.userManualToolStripMenuItem.Click += new System.EventHandler(this.userManualToolStripMenuItem_Click);
            // 
            // aboutSoftwareToolStripMenuItem
            // 
            this.aboutSoftwareToolStripMenuItem.Name = "aboutSoftwareToolStripMenuItem";
            this.aboutSoftwareToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.aboutSoftwareToolStripMenuItem.Text = "About Software ";
            this.aboutSoftwareToolStripMenuItem.Click += new System.EventHandler(this.aboutSoftwareToolStripMenuItem_Click);
            // 
            // groupBox8
            // 
            this.groupBox8.Controls.Add(this.btnbtconfirm);
            this.groupBox8.Controls.Add(this.txtbtype);
            this.groupBox8.Controls.Add(this.label31);
            this.groupBox8.Controls.Add(this.btnupdateBtype);
            this.groupBox8.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox8.Location = new System.Drawing.Point(623, 31);
            this.groupBox8.Margin = new System.Windows.Forms.Padding(2);
            this.groupBox8.Name = "groupBox8";
            this.groupBox8.Padding = new System.Windows.Forms.Padding(2);
            this.groupBox8.Size = new System.Drawing.Size(315, 56);
            this.groupBox8.TabIndex = 23;
            this.groupBox8.TabStop = false;
            // 
            // btnbtconfirm
            // 
            this.btnbtconfirm.Location = new System.Drawing.Point(242, 20);
            this.btnbtconfirm.Margin = new System.Windows.Forms.Padding(2);
            this.btnbtconfirm.Name = "btnbtconfirm";
            this.btnbtconfirm.Size = new System.Drawing.Size(56, 21);
            this.btnbtconfirm.TabIndex = 31;
            this.btnbtconfirm.Text = "Confirm";
            this.btnbtconfirm.UseVisualStyleBackColor = true;
            this.btnbtconfirm.Click += new System.EventHandler(this.btnbtconfirm_Click_1);
            // 
            // txtbtype
            // 
            this.txtbtype.Location = new System.Drawing.Point(112, 21);
            this.txtbtype.Margin = new System.Windows.Forms.Padding(2);
            this.txtbtype.Name = "txtbtype";
            this.txtbtype.Size = new System.Drawing.Size(53, 19);
            this.txtbtype.TabIndex = 30;
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Location = new System.Drawing.Point(32, 24);
            this.label31.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(61, 13);
            this.label31.TabIndex = 0;
            this.label31.Text = "Blood Type";
            // 
            // btnupdateBtype
            // 
            this.btnupdateBtype.Location = new System.Drawing.Point(178, 20);
            this.btnupdateBtype.Margin = new System.Windows.Forms.Padding(2);
            this.btnupdateBtype.Name = "btnupdateBtype";
            this.btnupdateBtype.Size = new System.Drawing.Size(56, 21);
            this.btnupdateBtype.TabIndex = 29;
            this.btnupdateBtype.Text = "Update";
            this.btnupdateBtype.UseVisualStyleBackColor = true;
            this.btnupdateBtype.Click += new System.EventHandler(this.btnupdateBtype_Click_1);
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.button2);
            this.groupBox5.Controls.Add(this.button1);
            this.groupBox5.Controls.Add(this.label30);
            this.groupBox5.Controls.Add(this.btncheck);
            this.groupBox5.Controls.Add(this.label29);
            this.groupBox5.Controls.Add(this.txtDNIC);
            this.groupBox5.Controls.Add(this.label24);
            this.groupBox5.Controls.Add(this.txtDDate);
            this.groupBox5.Controls.Add(this.txtbloodunitid);
            this.groupBox5.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox5.Location = new System.Drawing.Point(17, 31);
            this.groupBox5.Margin = new System.Windows.Forms.Padding(2);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Padding = new System.Windows.Forms.Padding(2);
            this.groupBox5.Size = new System.Drawing.Size(602, 96);
            this.groupBox5.TabIndex = 22;
            this.groupBox5.TabStop = false;
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(300, 31);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(28, 19);
            this.button2.TabIndex = 13;
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(146, 52);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 12;
            this.button1.Text = "Get ID";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Location = new System.Drawing.Point(360, 62);
            this.label30.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(30, 13);
            this.label30.TabIndex = 3;
            this.label30.Text = "Date";
            // 
            // btncheck
            // 
            this.btncheck.Location = new System.Drawing.Point(226, 52);
            this.btncheck.Margin = new System.Windows.Forms.Padding(2);
            this.btncheck.Name = "btncheck";
            this.btncheck.Size = new System.Drawing.Size(69, 23);
            this.btncheck.TabIndex = 11;
            this.btncheck.Text = "Check";
            this.btncheck.UseVisualStyleBackColor = true;
            this.btncheck.Click += new System.EventHandler(this.btncheck_Click);
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Location = new System.Drawing.Point(360, 31);
            this.label29.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(57, 13);
            this.label29.TabIndex = 2;
            this.label29.Text = "Donar NIC";
            // 
            // txtDNIC
            // 
            this.txtDNIC.Location = new System.Drawing.Point(448, 31);
            this.txtDNIC.Margin = new System.Windows.Forms.Padding(2);
            this.txtDNIC.Name = "txtDNIC";
            this.txtDNIC.Size = new System.Drawing.Size(115, 19);
            this.txtDNIC.TabIndex = 0;
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label24.Location = new System.Drawing.Point(24, 31);
            this.label24.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(83, 13);
            this.label24.TabIndex = 9;
            this.label24.Text = "Blood Unit ID";
            // 
            // txtDDate
            // 
            this.txtDDate.Location = new System.Drawing.Point(448, 59);
            this.txtDDate.Margin = new System.Windows.Forms.Padding(2);
            this.txtDDate.Name = "txtDDate";
            this.txtDDate.Size = new System.Drawing.Size(115, 19);
            this.txtDDate.TabIndex = 1;
            // 
            // txtbloodunitid
            // 
            this.txtbloodunitid.Location = new System.Drawing.Point(146, 31);
            this.txtbloodunitid.Margin = new System.Windows.Forms.Padding(2);
            this.txtbloodunitid.Name = "txtbloodunitid";
            this.txtbloodunitid.Size = new System.Drawing.Size(149, 19);
            this.txtbloodunitid.TabIndex = 10;
            // 
            // groupBox6
            // 
            this.groupBox6.Controls.Add(this.button21);
            this.groupBox6.Controls.Add(this.finalEligibility);
            this.groupBox6.Controls.Add(this.label23);
            this.groupBox6.Controls.Add(this.button20);
            this.groupBox6.Controls.Add(this.label25);
            this.groupBox6.Controls.Add(this.txtpan);
            this.groupBox6.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox6.Location = new System.Drawing.Point(349, 411);
            this.groupBox6.Margin = new System.Windows.Forms.Padding(2);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Padding = new System.Windows.Forms.Padding(2);
            this.groupBox6.Size = new System.Drawing.Size(589, 182);
            this.groupBox6.TabIndex = 21;
            this.groupBox6.TabStop = false;
            this.groupBox6.Text = "Final Eligibility";
            // 
            // button21
            // 
            this.button21.Location = new System.Drawing.Point(414, 135);
            this.button21.Margin = new System.Windows.Forms.Padding(2);
            this.button21.Name = "button21";
            this.button21.Size = new System.Drawing.Size(145, 26);
            this.button21.TabIndex = 9;
            this.button21.Text = "Check Next Blood Unit";
            this.button21.UseVisualStyleBackColor = true;
            this.button21.Click += new System.EventHandler(this.button21_Click);
            // 
            // finalEligibility
            // 
            this.finalEligibility.Location = new System.Drawing.Point(49, 93);
            this.finalEligibility.Margin = new System.Windows.Forms.Padding(2);
            this.finalEligibility.Name = "finalEligibility";
            this.finalEligibility.Size = new System.Drawing.Size(97, 36);
            this.finalEligibility.TabIndex = 39;
            this.finalEligibility.Text = "Check Eligibility";
            this.finalEligibility.UseVisualStyleBackColor = true;
            this.finalEligibility.Click += new System.EventHandler(this.finalEligibility_Click_1);
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label23.Location = new System.Drawing.Point(5, 50);
            this.label23.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(186, 13);
            this.label23.TabIndex = 5;
            this.label23.Text = "Donor lived in Pandemic Area ?";
            // 
            // button20
            // 
            this.button20.Location = new System.Drawing.Point(287, 49);
            this.button20.Margin = new System.Windows.Forms.Padding(2);
            this.button20.Name = "button20";
            this.button20.Size = new System.Drawing.Size(56, 22);
            this.button20.TabIndex = 7;
            this.button20.Text = "Go";
            this.button20.UseVisualStyleBackColor = true;
            this.button20.Click += new System.EventHandler(this.button20_Click_1);
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label25.Location = new System.Drawing.Point(159, 102);
            this.label25.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(113, 17);
            this.label25.TabIndex = 8;
            this.label25.Text = "Final Eligibility";
            // 
            // txtpan
            // 
            this.txtpan.Location = new System.Drawing.Point(194, 50);
            this.txtpan.Margin = new System.Windows.Forms.Padding(2);
            this.txtpan.Name = "txtpan";
            this.txtpan.Size = new System.Drawing.Size(76, 19);
            this.txtpan.TabIndex = 6;
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.label28);
            this.groupBox4.Controls.Add(this.label27);
            this.groupBox4.Controls.Add(this.label26);
            this.groupBox4.Controls.Add(this.label22);
            this.groupBox4.Controls.Add(this.label21);
            this.groupBox4.Controls.Add(this.label20);
            this.groupBox4.Controls.Add(this.btnlipidupdate);
            this.groupBox4.Controls.Add(this.btnlipidconfirm);
            this.groupBox4.Controls.Add(this.btnlipidinsert);
            this.groupBox4.Controls.Add(this.txtLDLHDL);
            this.groupBox4.Controls.Add(this.txtCHOLHDL);
            this.groupBox4.Controls.Add(this.txtCVLDL);
            this.groupBox4.Controls.Add(this.txtCLDL);
            this.groupBox4.Controls.Add(this.txtCNonHDL);
            this.groupBox4.Controls.Add(this.txtCHDL);
            this.groupBox4.Controls.Add(this.txtTriglycerides);
            this.groupBox4.Controls.Add(this.txtcholesterol);
            this.groupBox4.Controls.Add(this.label19);
            this.groupBox4.Controls.Add(this.label12);
            this.groupBox4.Controls.Add(this.label13);
            this.groupBox4.Controls.Add(this.label14);
            this.groupBox4.Controls.Add(this.label15);
            this.groupBox4.Controls.Add(this.label16);
            this.groupBox4.Controls.Add(this.label17);
            this.groupBox4.Controls.Add(this.label18);
            this.groupBox4.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox4.Location = new System.Drawing.Point(17, 132);
            this.groupBox4.Margin = new System.Windows.Forms.Padding(2);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Padding = new System.Windows.Forms.Padding(2);
            this.groupBox4.Size = new System.Drawing.Size(328, 461);
            this.groupBox4.TabIndex = 20;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "LIPID PROFILE";
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Location = new System.Drawing.Point(259, 278);
            this.label28.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(41, 13);
            this.label28.TabIndex = 55;
            this.label28.Text = " mg/dL";
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Location = new System.Drawing.Point(259, 233);
            this.label27.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(41, 13);
            this.label27.TabIndex = 54;
            this.label27.Text = " mg/dL";
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Location = new System.Drawing.Point(259, 185);
            this.label26.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(41, 13);
            this.label26.TabIndex = 53;
            this.label26.Text = " mg/dL";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Location = new System.Drawing.Point(259, 140);
            this.label22.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(41, 13);
            this.label22.TabIndex = 52;
            this.label22.Text = " mg/dL";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(259, 94);
            this.label21.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(41, 13);
            this.label21.TabIndex = 51;
            this.label21.Text = " mg/dL";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(259, 50);
            this.label20.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(41, 13);
            this.label20.TabIndex = 50;
            this.label20.Text = " mg/dL";
            // 
            // btnlipidupdate
            // 
            this.btnlipidupdate.Location = new System.Drawing.Point(100, 421);
            this.btnlipidupdate.Margin = new System.Windows.Forms.Padding(2);
            this.btnlipidupdate.Name = "btnlipidupdate";
            this.btnlipidupdate.Size = new System.Drawing.Size(56, 21);
            this.btnlipidupdate.TabIndex = 49;
            this.btnlipidupdate.Text = "Update";
            this.btnlipidupdate.UseVisualStyleBackColor = true;
            this.btnlipidupdate.Click += new System.EventHandler(this.btnlipidupdate_Click_1);
            // 
            // btnlipidconfirm
            // 
            this.btnlipidconfirm.Location = new System.Drawing.Point(172, 421);
            this.btnlipidconfirm.Margin = new System.Windows.Forms.Padding(2);
            this.btnlipidconfirm.Name = "btnlipidconfirm";
            this.btnlipidconfirm.Size = new System.Drawing.Size(56, 21);
            this.btnlipidconfirm.TabIndex = 48;
            this.btnlipidconfirm.Text = "Confirm";
            this.btnlipidconfirm.UseVisualStyleBackColor = true;
            this.btnlipidconfirm.Click += new System.EventHandler(this.btnlipidconfirm_Click_1);
            // 
            // btnlipidinsert
            // 
            this.btnlipidinsert.Location = new System.Drawing.Point(245, 421);
            this.btnlipidinsert.Margin = new System.Windows.Forms.Padding(2);
            this.btnlipidinsert.Name = "btnlipidinsert";
            this.btnlipidinsert.Size = new System.Drawing.Size(56, 21);
            this.btnlipidinsert.TabIndex = 47;
            this.btnlipidinsert.Text = "Insert";
            this.btnlipidinsert.UseVisualStyleBackColor = true;
            this.btnlipidinsert.Click += new System.EventHandler(this.btnlipidinsert_Click_1);
            // 
            // txtLDLHDL
            // 
            this.txtLDLHDL.Location = new System.Drawing.Point(172, 371);
            this.txtLDLHDL.Name = "txtLDLHDL";
            this.txtLDLHDL.Size = new System.Drawing.Size(83, 19);
            this.txtLDLHDL.TabIndex = 46;
            // 
            // txtCHOLHDL
            // 
            this.txtCHOLHDL.Location = new System.Drawing.Point(172, 325);
            this.txtCHOLHDL.Name = "txtCHOLHDL";
            this.txtCHOLHDL.Size = new System.Drawing.Size(83, 19);
            this.txtCHOLHDL.TabIndex = 45;
            // 
            // txtCVLDL
            // 
            this.txtCVLDL.Location = new System.Drawing.Point(172, 275);
            this.txtCVLDL.Name = "txtCVLDL";
            this.txtCVLDL.Size = new System.Drawing.Size(83, 19);
            this.txtCVLDL.TabIndex = 44;
            // 
            // txtCLDL
            // 
            this.txtCLDL.Location = new System.Drawing.Point(172, 231);
            this.txtCLDL.Name = "txtCLDL";
            this.txtCLDL.Size = new System.Drawing.Size(83, 19);
            this.txtCLDL.TabIndex = 43;
            // 
            // txtCNonHDL
            // 
            this.txtCNonHDL.Location = new System.Drawing.Point(172, 183);
            this.txtCNonHDL.Name = "txtCNonHDL";
            this.txtCNonHDL.Size = new System.Drawing.Size(83, 19);
            this.txtCNonHDL.TabIndex = 42;
            // 
            // txtCHDL
            // 
            this.txtCHDL.Location = new System.Drawing.Point(172, 137);
            this.txtCHDL.Name = "txtCHDL";
            this.txtCHDL.Size = new System.Drawing.Size(83, 19);
            this.txtCHDL.TabIndex = 41;
            // 
            // txtTriglycerides
            // 
            this.txtTriglycerides.Location = new System.Drawing.Point(172, 90);
            this.txtTriglycerides.Name = "txtTriglycerides";
            this.txtTriglycerides.Size = new System.Drawing.Size(83, 19);
            this.txtTriglycerides.TabIndex = 40;
            // 
            // txtcholesterol
            // 
            this.txtcholesterol.Location = new System.Drawing.Point(172, 48);
            this.txtcholesterol.Name = "txtcholesterol";
            this.txtcholesterol.Size = new System.Drawing.Size(83, 19);
            this.txtcholesterol.TabIndex = 39;
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(13, 371);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(52, 13);
            this.label19.TabIndex = 38;
            this.label19.Text = "LDL-HDL";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(13, 325);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(61, 13);
            this.label12.TabIndex = 37;
            this.label12.Text = "CHOL-HDL";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(13, 275);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(89, 13);
            this.label13.TabIndex = 36;
            this.label13.Text = "Cholesterol VLDL";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(13, 231);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(82, 13);
            this.label14.TabIndex = 35;
            this.label14.Text = "Cholesterol LDL";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(13, 183);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(107, 13);
            this.label15.TabIndex = 34;
            this.label15.Text = "Cholesterol Non HDL";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(13, 137);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(84, 13);
            this.label16.TabIndex = 33;
            this.label16.Text = "Cholesterol HDL";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(13, 90);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(99, 13);
            this.label17.TabIndex = 32;
            this.label17.Text = "Serum Triglycerides";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(13, 48);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(119, 13);
            this.label18.TabIndex = 31;
            this.label18.Text = "Serum Cholesterol Total";
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.lbsyphilis);
            this.groupBox3.Controls.Add(this.btnsyphilisisupdate);
            this.groupBox3.Controls.Add(this.btnsyphiliseligibility);
            this.groupBox3.Controls.Add(this.btnsyphilisinsert);
            this.groupBox3.Controls.Add(this.btnsyphilisconfirm);
            this.groupBox3.Controls.Add(this.cbsperdr);
            this.groupBox3.Controls.Add(this.cbnonsperdr);
            this.groupBox3.Controls.Add(this.label9);
            this.groupBox3.Controls.Add(this.label10);
            this.groupBox3.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox3.Location = new System.Drawing.Point(623, 241);
            this.groupBox3.Margin = new System.Windows.Forms.Padding(2);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Padding = new System.Windows.Forms.Padding(2);
            this.groupBox3.Size = new System.Drawing.Size(315, 165);
            this.groupBox3.TabIndex = 19;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "SYPHILIS";
            // 
            // lbsyphilis
            // 
            this.lbsyphilis.AutoSize = true;
            this.lbsyphilis.Location = new System.Drawing.Point(230, 132);
            this.lbsyphilis.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lbsyphilis.Name = "lbsyphilis";
            this.lbsyphilis.Size = new System.Drawing.Size(46, 13);
            this.lbsyphilis.TabIndex = 45;
            this.lbsyphilis.Text = "Eligibility";
            // 
            // btnsyphilisisupdate
            // 
            this.btnsyphilisisupdate.Location = new System.Drawing.Point(112, 94);
            this.btnsyphilisisupdate.Margin = new System.Windows.Forms.Padding(2);
            this.btnsyphilisisupdate.Name = "btnsyphilisisupdate";
            this.btnsyphilisisupdate.Size = new System.Drawing.Size(56, 21);
            this.btnsyphilisisupdate.TabIndex = 38;
            this.btnsyphilisisupdate.Text = "Update";
            this.btnsyphilisisupdate.UseVisualStyleBackColor = true;
            this.btnsyphilisisupdate.Click += new System.EventHandler(this.btnsyphilisisupdate_Click_1);
            // 
            // btnsyphiliseligibility
            // 
            this.btnsyphiliseligibility.Location = new System.Drawing.Point(131, 128);
            this.btnsyphiliseligibility.Margin = new System.Windows.Forms.Padding(2);
            this.btnsyphiliseligibility.Name = "btnsyphiliseligibility";
            this.btnsyphiliseligibility.Size = new System.Drawing.Size(97, 21);
            this.btnsyphiliseligibility.TabIndex = 44;
            this.btnsyphiliseligibility.Text = "Check Eligibility";
            this.btnsyphiliseligibility.UseVisualStyleBackColor = true;
            this.btnsyphiliseligibility.Click += new System.EventHandler(this.btnsyphiliseligibility_Click_1);
            // 
            // btnsyphilisinsert
            // 
            this.btnsyphilisinsert.Location = new System.Drawing.Point(244, 94);
            this.btnsyphilisinsert.Margin = new System.Windows.Forms.Padding(2);
            this.btnsyphilisinsert.Name = "btnsyphilisinsert";
            this.btnsyphilisinsert.Size = new System.Drawing.Size(56, 21);
            this.btnsyphilisinsert.TabIndex = 36;
            this.btnsyphilisinsert.Text = "Insert";
            this.btnsyphilisinsert.UseVisualStyleBackColor = true;
            this.btnsyphilisinsert.Click += new System.EventHandler(this.btnsyphilisinsert_Click_1);
            // 
            // btnsyphilisconfirm
            // 
            this.btnsyphilisconfirm.Location = new System.Drawing.Point(178, 94);
            this.btnsyphilisconfirm.Margin = new System.Windows.Forms.Padding(2);
            this.btnsyphilisconfirm.Name = "btnsyphilisconfirm";
            this.btnsyphilisconfirm.Size = new System.Drawing.Size(56, 21);
            this.btnsyphilisconfirm.TabIndex = 37;
            this.btnsyphilisconfirm.Text = "Confirm";
            this.btnsyphilisconfirm.UseVisualStyleBackColor = true;
            this.btnsyphilisconfirm.Click += new System.EventHandler(this.btnsyphilisconfirm_Click_1);
            // 
            // cbsperdr
            // 
            this.cbsperdr.FormattingEnabled = true;
            this.cbsperdr.Items.AddRange(new object[] {
            "NonReactive",
            "Reactive"});
            this.cbsperdr.Location = new System.Drawing.Point(180, 63);
            this.cbsperdr.Name = "cbsperdr";
            this.cbsperdr.Size = new System.Drawing.Size(121, 21);
            this.cbsperdr.TabIndex = 24;
            // 
            // cbnonsperdr
            // 
            this.cbnonsperdr.FormattingEnabled = true;
            this.cbnonsperdr.Items.AddRange(new object[] {
            "NonReactive",
            "Reactive"});
            this.cbnonsperdr.Location = new System.Drawing.Point(5, 63);
            this.cbnonsperdr.Name = "cbnonsperdr";
            this.cbnonsperdr.Size = new System.Drawing.Size(121, 21);
            this.cbnonsperdr.TabIndex = 23;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(201, 32);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(81, 13);
            this.label9.TabIndex = 22;
            this.label9.Text = "SPECIFIC RDR";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(11, 32);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(108, 13);
            this.label10.TabIndex = 21;
            this.label10.Text = "NON-SPECIFIC RDR";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.lbhepatitis);
            this.groupBox2.Controls.Add(this.cbHepatitis);
            this.groupBox2.Controls.Add(this.btnhepatitiseligibility);
            this.groupBox2.Controls.Add(this.label3);
            this.groupBox2.Controls.Add(this.btnhepatitisupdate);
            this.groupBox2.Controls.Add(this.btnhepatitisinsert);
            this.groupBox2.Controls.Add(this.btnhepatitisconfirm);
            this.groupBox2.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox2.Location = new System.Drawing.Point(623, 92);
            this.groupBox2.Margin = new System.Windows.Forms.Padding(2);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Padding = new System.Windows.Forms.Padding(2);
            this.groupBox2.Size = new System.Drawing.Size(315, 144);
            this.groupBox2.TabIndex = 18;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = " HEPATITIS B SURFACE ANTIGEN";
            // 
            // lbhepatitis
            // 
            this.lbhepatitis.AutoSize = true;
            this.lbhepatitis.Location = new System.Drawing.Point(230, 110);
            this.lbhepatitis.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lbhepatitis.Name = "lbhepatitis";
            this.lbhepatitis.Size = new System.Drawing.Size(46, 13);
            this.lbhepatitis.TabIndex = 43;
            this.lbhepatitis.Text = "Eligibility";
            // 
            // cbHepatitis
            // 
            this.cbHepatitis.FormattingEnabled = true;
            this.cbHepatitis.Items.AddRange(new object[] {
            "Reactive",
            "Non_Reactive"});
            this.cbHepatitis.Location = new System.Drawing.Point(166, 30);
            this.cbHepatitis.Margin = new System.Windows.Forms.Padding(2);
            this.cbHepatitis.Name = "cbHepatitis";
            this.cbHepatitis.Size = new System.Drawing.Size(135, 21);
            this.cbHepatitis.TabIndex = 7;
            // 
            // btnhepatitiseligibility
            // 
            this.btnhepatitiseligibility.Location = new System.Drawing.Point(131, 102);
            this.btnhepatitiseligibility.Margin = new System.Windows.Forms.Padding(2);
            this.btnhepatitiseligibility.Name = "btnhepatitiseligibility";
            this.btnhepatitiseligibility.Size = new System.Drawing.Size(97, 21);
            this.btnhepatitiseligibility.TabIndex = 42;
            this.btnhepatitiseligibility.Text = "Check Eligibility";
            this.btnhepatitiseligibility.UseVisualStyleBackColor = true;
            this.btnhepatitiseligibility.Click += new System.EventHandler(this.btnhepatitiseligibility_Click_1);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(11, 32);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(137, 13);
            this.label3.TabIndex = 6;
            this.label3.Text = "Hepatitis B Surface Antigen";
            // 
            // btnhepatitisupdate
            // 
            this.btnhepatitisupdate.Location = new System.Drawing.Point(112, 63);
            this.btnhepatitisupdate.Margin = new System.Windows.Forms.Padding(2);
            this.btnhepatitisupdate.Name = "btnhepatitisupdate";
            this.btnhepatitisupdate.Size = new System.Drawing.Size(56, 21);
            this.btnhepatitisupdate.TabIndex = 33;
            this.btnhepatitisupdate.Text = "Update";
            this.btnhepatitisupdate.UseVisualStyleBackColor = true;
            this.btnhepatitisupdate.Click += new System.EventHandler(this.btnhepatitisupdate_Click_1);
            // 
            // btnhepatitisinsert
            // 
            this.btnhepatitisinsert.Location = new System.Drawing.Point(244, 63);
            this.btnhepatitisinsert.Margin = new System.Windows.Forms.Padding(2);
            this.btnhepatitisinsert.Name = "btnhepatitisinsert";
            this.btnhepatitisinsert.Size = new System.Drawing.Size(56, 21);
            this.btnhepatitisinsert.TabIndex = 31;
            this.btnhepatitisinsert.Text = "Insert";
            this.btnhepatitisinsert.UseVisualStyleBackColor = true;
            this.btnhepatitisinsert.Click += new System.EventHandler(this.btnhepatitisinsert_Click_1);
            // 
            // btnhepatitisconfirm
            // 
            this.btnhepatitisconfirm.Location = new System.Drawing.Point(178, 63);
            this.btnhepatitisconfirm.Margin = new System.Windows.Forms.Padding(2);
            this.btnhepatitisconfirm.Name = "btnhepatitisconfirm";
            this.btnhepatitisconfirm.Size = new System.Drawing.Size(56, 21);
            this.btnhepatitisconfirm.TabIndex = 32;
            this.btnhepatitisconfirm.Text = "Confirm";
            this.btnhepatitisconfirm.UseVisualStyleBackColor = true;
            this.btnhepatitisconfirm.Click += new System.EventHandler(this.btnhepatitisconfirm_Click_1);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.lbhiv);
            this.groupBox1.Controls.Add(this.btnhiveligibility);
            this.groupBox1.Controls.Add(this.btnhivupdate);
            this.groupBox1.Controls.Add(this.btnhivconfirm);
            this.groupBox1.Controls.Add(this.btnhivinsert);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.txthivrna);
            this.groupBox1.Controls.Add(this.txthiv2);
            this.groupBox1.Controls.Add(this.txthiv1);
            this.groupBox1.Controls.Add(this.txtGRF);
            this.groupBox1.Controls.Add(this.label8);
            this.groupBox1.Controls.Add(this.label7);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.Location = new System.Drawing.Point(349, 132);
            this.groupBox1.Margin = new System.Windows.Forms.Padding(2);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(2);
            this.groupBox1.Size = new System.Drawing.Size(269, 274);
            this.groupBox1.TabIndex = 17;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "HIV ANTIBODY TEST";
            // 
            // lbhiv
            // 
            this.lbhiv.AutoSize = true;
            this.lbhiv.Location = new System.Drawing.Point(181, 240);
            this.lbhiv.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lbhiv.Name = "lbhiv";
            this.lbhiv.Size = new System.Drawing.Size(46, 13);
            this.lbhiv.TabIndex = 41;
            this.lbhiv.Text = "Eligibility";
            // 
            // btnhiveligibility
            // 
            this.btnhiveligibility.Location = new System.Drawing.Point(80, 236);
            this.btnhiveligibility.Margin = new System.Windows.Forms.Padding(2);
            this.btnhiveligibility.Name = "btnhiveligibility";
            this.btnhiveligibility.Size = new System.Drawing.Size(97, 21);
            this.btnhiveligibility.TabIndex = 40;
            this.btnhiveligibility.Text = "Check Eligibility";
            this.btnhiveligibility.UseVisualStyleBackColor = true;
            this.btnhiveligibility.Click += new System.EventHandler(this.btnhiveligibility_Click_1);
            // 
            // btnhivupdate
            // 
            this.btnhivupdate.Location = new System.Drawing.Point(58, 203);
            this.btnhivupdate.Margin = new System.Windows.Forms.Padding(2);
            this.btnhivupdate.Name = "btnhivupdate";
            this.btnhivupdate.Size = new System.Drawing.Size(56, 21);
            this.btnhivupdate.TabIndex = 28;
            this.btnhivupdate.Text = "Update";
            this.btnhivupdate.UseVisualStyleBackColor = true;
            this.btnhivupdate.Click += new System.EventHandler(this.btnhivupdate_Click_1);
            // 
            // btnhivconfirm
            // 
            this.btnhivconfirm.Location = new System.Drawing.Point(127, 203);
            this.btnhivconfirm.Margin = new System.Windows.Forms.Padding(2);
            this.btnhivconfirm.Name = "btnhivconfirm";
            this.btnhivconfirm.Size = new System.Drawing.Size(56, 21);
            this.btnhivconfirm.TabIndex = 27;
            this.btnhivconfirm.Text = "Confirm";
            this.btnhivconfirm.UseVisualStyleBackColor = true;
            this.btnhivconfirm.Click += new System.EventHandler(this.btnhivconfirm_Click_1);
            // 
            // btnhivinsert
            // 
            this.btnhivinsert.Location = new System.Drawing.Point(194, 203);
            this.btnhivinsert.Margin = new System.Windows.Forms.Padding(2);
            this.btnhivinsert.Name = "btnhivinsert";
            this.btnhivinsert.Size = new System.Drawing.Size(56, 21);
            this.btnhivinsert.TabIndex = 26;
            this.btnhivinsert.Text = "Insert";
            this.btnhivinsert.UseVisualStyleBackColor = true;
            this.btnhivinsert.Click += new System.EventHandler(this.btnhivinsert_Click_1);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(204, 56);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(42, 13);
            this.label1.TabIndex = 25;
            this.label1.Text = "mL/min";
            // 
            // txthivrna
            // 
            this.txthivrna.Location = new System.Drawing.Point(100, 174);
            this.txthivrna.Name = "txthivrna";
            this.txthivrna.Size = new System.Drawing.Size(100, 19);
            this.txthivrna.TabIndex = 24;
            // 
            // txthiv2
            // 
            this.txthiv2.Location = new System.Drawing.Point(100, 133);
            this.txthiv2.Name = "txthiv2";
            this.txthiv2.Size = new System.Drawing.Size(100, 19);
            this.txthiv2.TabIndex = 23;
            // 
            // txthiv1
            // 
            this.txthiv1.Location = new System.Drawing.Point(100, 94);
            this.txthiv1.Name = "txthiv1";
            this.txthiv1.Size = new System.Drawing.Size(100, 19);
            this.txthiv1.TabIndex = 22;
            // 
            // txtGRF
            // 
            this.txtGRF.Location = new System.Drawing.Point(100, 54);
            this.txtGRF.Name = "txtGRF";
            this.txtGRF.Size = new System.Drawing.Size(100, 19);
            this.txtGRF.TabIndex = 21;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(5, 178);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(51, 13);
            this.label8.TabIndex = 20;
            this.label8.Text = "HIV-RNA";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(5, 137);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(31, 13);
            this.label7.TabIndex = 19;
            this.label7.Text = "HIV2";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(5, 98);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(31, 13);
            this.label6.TabIndex = 18;
            this.label6.Text = "HIV1";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(5, 54);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(78, 13);
            this.label5.TabIndex = 17;
            this.label5.Text = "GFR Estimated";
            // 
            // LAB
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Window;
            this.ClientSize = new System.Drawing.Size(958, 605);
            this.Controls.Add(this.groupBox8);
            this.Controls.Add(this.groupBox5);
            this.Controls.Add(this.groupBox6);
            this.Controls.Add(this.groupBox4);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.menuStrip1);
            this.Cursor = System.Windows.Forms.Cursors.Hand;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "LAB";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "LAB";
            this.Load += new System.EventHandler(this.LAB_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.groupBox8.ResumeLayout(false);
            this.groupBox8.PerformLayout();
            this.groupBox5.ResumeLayout(false);
            this.groupBox5.PerformLayout();
            this.groupBox6.ResumeLayout(false);
            this.groupBox6.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem viewAccountToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem viewAndEditAccountToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem aboutWhatToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem userManualToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem aboutSoftwareToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem backToTheMainMenuToolStripMenuItem;
        private System.Windows.Forms.GroupBox groupBox8;
        private System.Windows.Forms.Button btnbtconfirm;
        private System.Windows.Forms.TextBox txtbtype;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.Button btnupdateBtype;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.Button btncheck;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.TextBox txtDNIC;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.TextBox txtDDate;
        private System.Windows.Forms.TextBox txtbloodunitid;
        private System.Windows.Forms.GroupBox groupBox6;
        private System.Windows.Forms.Button button21;
        private System.Windows.Forms.Button finalEligibility;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Button button20;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.TextBox txtpan;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Button btnlipidupdate;
        private System.Windows.Forms.Button btnlipidconfirm;
        private System.Windows.Forms.Button btnlipidinsert;
        private System.Windows.Forms.TextBox txtLDLHDL;
        private System.Windows.Forms.TextBox txtCHOLHDL;
        private System.Windows.Forms.TextBox txtCVLDL;
        private System.Windows.Forms.TextBox txtCLDL;
        private System.Windows.Forms.TextBox txtCNonHDL;
        private System.Windows.Forms.TextBox txtCHDL;
        private System.Windows.Forms.TextBox txtTriglycerides;
        private System.Windows.Forms.TextBox txtcholesterol;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Label lbsyphilis;
        private System.Windows.Forms.Button btnsyphilisisupdate;
        private System.Windows.Forms.Button btnsyphiliseligibility;
        private System.Windows.Forms.Button btnsyphilisinsert;
        private System.Windows.Forms.Button btnsyphilisconfirm;
        private System.Windows.Forms.ComboBox cbsperdr;
        private System.Windows.Forms.ComboBox cbnonsperdr;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Label lbhepatitis;
        private System.Windows.Forms.ComboBox cbHepatitis;
        private System.Windows.Forms.Button btnhepatitiseligibility;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button btnhepatitisupdate;
        private System.Windows.Forms.Button btnhepatitisinsert;
        private System.Windows.Forms.Button btnhepatitisconfirm;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label lbhiv;
        private System.Windows.Forms.Button btnhiveligibility;
        private System.Windows.Forms.Button btnhivupdate;
        private System.Windows.Forms.Button btnhivconfirm;
        private System.Windows.Forms.Button btnhivinsert;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txthivrna;
        private System.Windows.Forms.TextBox txthiv2;
        private System.Windows.Forms.TextBox txthiv1;
        private System.Windows.Forms.TextBox txtGRF;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button1;
    }
}