﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Blood_Bank
{
    static class DonarExpression
    {
        static public string[] donarExpresion = new string[13];
    }
}
